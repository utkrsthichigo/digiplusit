function addNode() {
    var tree = document.getElementById('tree');
    var rootNode = document.getElementById('root');
    var nodeNameInput = document.getElementById('nodeNameInput');
    var newNode = createNodeElement(nodeNameInput.value, 'root');
    tree.appendChild(newNode);
    nodeNameInput.value = ''; // Clear the input field
}

function addChild(parentNodeId) {
    var parentNode = document.getElementById(parentNodeId);
    var childrenContainer = parentNode.querySelector('ul');
    var nodeNameInput = document.getElementById('nodeNameInput');
    var newNode = createNodeElement(nodeNameInput.value, parentNode.id);
    childrenContainer.appendChild(newNode);
    nodeNameInput.value = ''; // Clear the input field
}

function deleteNode(nodeId) {
    var node = document.getElementById(nodeId);
    node.parentNode.removeChild(node);
}

function updateNode(nodeId) {
    var node = document.getElementById(nodeId);
    var newName = prompt('Enter a new name for the node:', node.querySelector('span').textContent.trim());
    if (newName !== null) {
        node.querySelector('span').textContent = newName;
    }
}

function createNodeElement(nodeText, parentId) {
    var newNode = document.createElement('li');
    newNode.classList.add('node');
    newNode.innerHTML = `
        <span>${nodeText}</span>
        <button class="add-child-btn" onclick="addChild('${newNode.id}')">Add Child</button>
        <button class="delete-btn" onclick="deleteNode('${newNode.id}')">Delete</button>
        <button class="update-btn" onclick="updateNode('${newNode.id}')">Update</button>
        <ul id="${newNode.id}-children"></ul>
    `;
    newNode.id = generateNodeId(parentId);
    return newNode;
}

function generateNodeId(parentId) {
    return parentId + '-child-' + new Date().getTime();
}
